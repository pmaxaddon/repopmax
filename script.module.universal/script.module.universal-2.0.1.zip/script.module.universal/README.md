script.module.universal
=======================

Universal - An Addons Toolkit for XBMC - Allows addons developers to quickly add various functionalities like maintaining and managing watch history, favorites, and resume / play from multiple devices and media queuing.

Checkout the wiki for tutorials: https://github.com/the-one-/script.module.universal/wiki
