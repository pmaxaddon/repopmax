service.subtitles.subdivx
=========================

Subdivx.com subtitle service plugin for XBMC 13 Gotham or newer. Ported from
the pre-Gotham version. All the credit to its authors.
