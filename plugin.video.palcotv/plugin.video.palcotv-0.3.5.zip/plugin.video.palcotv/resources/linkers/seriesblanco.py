# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Linker SeriesBlanco para PalcoTV
# Version 0.4 (30/07/2016)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Librerías Plugintools por Jesús (www.mimediacenter.info)
#------------------------------------------------------------

import os
import sys
import urllib
import urllib2
import re
import shutil
import zipfile

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

import plugintools
from resources.tools.resolvers import *
from resources.tools.media_analyzer import *

playlists = xbmc.translatePath(os.path.join('special://userdata/playlists', ''))
temp = xbmc.translatePath(os.path.join('special://userdata/playlists/tmp', ''))

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

referer = "http://seriesblanco.com/"   
thumbnail = "https://www.cubbyusercontent.com/pl/Seriesblanco_logo.png/_16feca772f2b4d089789a6d07e8cf8d6"
fanart = "https://www.cubbyusercontent.com/pl/Seriesblanco_fanart.jpg/_f163ece14fc641dfa23e938ceec862ef" 

sc = "[COLOR white]";ec = "[/COLOR]"
sc2 = "[COLOR palegreen]";ec2 = "[/COLOR]"
sc3 = "[COLOR seagreen]";ec3 = "[/COLOR]"
sc4 = "[COLOR red]";ec4 = "[/COLOR]"
sc5 = "[COLOR yellowgreen]";ec5 = "[/COLOR]"
version = " [0.4]"

def seriesblanco_linker0(params):
    plugintools.log('[%s %s] Linker SeriesBlanco %s' % (addonName, addonVersion, repr(params)))

    plugintools.add_item(action="",url="",title="[COLOR lightblue][B]Linker SeriesBlanco"+version+"[/B][COLOR lightblue]"+sc4+"[I] *** By PalcoTV Team ***[/I]"+ec4,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)

    url = params.get("url")    
    referer = url
    data = gethttp_referer_headers(url,referer)
    #plugintools.log("data= "+data)
    fondo = plugintools.find_single_match(data, "<meta property='og:image' content='(.*?)'")
    if fondo == "": fondo = fanart
    logo = plugintools.find_single_match(data,"<img id='port_serie' src='([^']+)'")
    if logo == "": logo = thumbnail
    info = plugintools.find_single_match(data, "<img id='port_serie'(.*?)</tbody></table>")
    votos = plugintools.find_single_match(info,"color='yellow'>(.*?)<").strip()
    if votos =="": votos = "N/D"
    title_ser = plugintools.find_single_match(info, "<h4>(.*?)</h4>").decode('unicode_escape').encode('utf8').strip()
    if title_ser == "": title_ser = "N/D"
    genr = plugintools.find_single_match(info, "<font color='skyblue'>G.*?nero:</font></b>(.*?)<br>").decode('unicode_escape').encode('utf8').strip()
    if genr == "": genr = "N/D"
    prod_ser = plugintools.find_single_match(info, "color='skyblue'>Productora[^<]+</font></b>(.*?)<br>").decode('unicode_escape').encode('utf8').strip()
    if prod_ser == "": prod_ser = "N/D"
    pais_ser = plugintools.find_single_match(info, "color='skyblue'>Pa[^<]+</font></b>(.*?)<br>").decode('unicode_escape').encode('utf8').strip()
    if pais_ser == "": pais_ser = "N/D"
    time_ser = plugintools.find_single_match(info,"color='skyblue'>Duraci[^<]+</font></b>(.*?)<br>").decode('unicode_escape').encode('utf8').strip()
    if time_ser == "": time_ser = "N/D"
    temp = plugintools.find_multiple_matches(data, "<h2 style='cursor: hand; cursor: pointer;'>(.*?)</tbody></table>")
    n_temp = len(temp)
    sinopsis = plugintools.find_single_match(info,"<p>(.*?)</p>").decode('unicode_escape').encode('utf8')
    sinopsis = sinopsis.replace('<br/>','').replace('<br />','').replace('<br>','').strip()
    if sinopsis == "": sinopsis = "N/D"
    
    datamovie = {
    'season': sc3+'[B]Temporadas Disponibles: [/B]'+ec3+sc+str(n_temp)+', '+ec,
    'votes': sc3+'[B]Votos: [/B]'+ec3+sc+str(votos)+', '+ec,
    'genre': sc3+'[B]Género: [/B]'+ec3+sc+str(genr)+', '+ec,
    'studio': sc3+'[B]Productora: [/B]'+ec3+sc+str(prod_ser)+', '+ec,
    'duration': sc3+'[B]Duración: [/B]'+ec3+sc+str(time_ser)+'[CR]'+ec,
    'sinopsis': sc3+'[B]Sinopsis: [/B]'+ec3+sc+str(sinopsis)+ec}
    
    datamovie["plot"]=datamovie["season"]+datamovie["votes"]+datamovie["genre"]+datamovie["studio"]+datamovie["duration"]+datamovie["sinopsis"]

    plugintools.add_item(action="",title=sc5+"[B]"+title_ser+"[/B]"+ec5,url="",info_labels=datamovie,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)
    for item in temp:
        title_temp = plugintools.find_single_match(item, "<u>(.*?)</u></h2>").decode('unicode_escape').encode('utf8')
        cap_temp = plugintools.find_multiple_matches(item,"<tr><td>(.*?)</td>")
        plugintools.add_item(action="",title=sc2+'-- '+title_temp+' --'+ec2,url="",thumbnail=logo,info_labels=datamovie,plot=sinopsis,fanart=fondo,folder=False,isPlayable=False)
        for cap in cap_temp:
            url_cap = plugintools.find_single_match(cap, "<a href='([^']+)")
            url_cap = 'http://www.seriesblanco.com'+url_cap
            title_cap = plugintools.find_single_match(cap, "'>(.*?)</a>")
            plugintools.addPeli(action="seriesblanco_linker1",title=sc+title_cap+ec,url=url_cap,thumbnail=logo,info_labels=datamovie,plot=sinopsis,fanart=fondo,folder=True,isPlayable=False)
    
def seriesblanco_linker1(params):
    plugintools.log('[%s %s] Linker SeriesBlanco %s' % (addonName, addonVersion, repr(params)))

    sinopsis = params.get("plot")
    datamovie = {}
    datamovie["Plot"]=sinopsis

    thumbnail = params.get("thumbnail")
    fanart = params.get("fanart")  
    
    headers = {'Host':"seriesblanco.com","User-Agent": 'User-Agent=Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; es-ES; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12', 
    "Referer": referer}
    url = params.get("url").replace('www.seriesblanco.com','seriesblanco.com')
    r = requests.get(url,headers=headers)
    data = r.content
    plugintools.add_item(action="",url="",title="[COLOR lightblue][B]Linker SeriesBlanco"+version+"[/B][COLOR lightblue]"+sc4+"[I] *** By PalcoTV Team ***[/I]"+ec4,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=False)
    ###### No hay peticion Ajax ######
    match_listacapis = plugintools.find_single_match(data,"<h2>Visionados Online</h2>(.*?)<h2>Descarga</h2>")
    ###### Si hay peticion Ajax ######
    if match_listacapis =="":
        ###### Buscando la url y datos del envio post a la peticion ajax ######
        ajax = plugintools.find_single_match(data,"function LoadGrid(.*?)success:")
        ajaxrequest = plugintools.find_single_match(ajax,"url : '(.*?)'.*?data : \"(.*?)\"")
        ###### Petición ajax ######
        url_ajax = scrapertools.cache_page(referer + ajaxrequest[0], ajaxrequest[1])
        custom_post=ajaxrequest[1]
        body,response_headers = plugintools.read_body_and_headers(referer+ajaxrequest[0],post=custom_post)
        #plugintools.log("data= "+data)
        match_listacapis = plugintools.find_single_match(body,'<h2>Visionados Online</h2>(.*?)</table>')

    match_capi = plugintools.find_multiple_matches(match_listacapis,'<td><div class="grid_content sno">(.*?)</tr>')
    
    for entry in match_capi:
        img = plugintools.find_single_match(entry,"src='/servidores([^']+)")
        url_img = 'http://www.seriesblanco.com/servidores'+img
        url_capi = plugintools.find_single_match(entry,'<a href="([^"]+)"')
        #url_capi = 'http://www.seriesblanco.com'+url_capi
        #Puede ser seriesblanco.tv o seriesblanco.com
        lang_audio = plugintools.find_single_match(entry,'<img src="http://seriesblanco.tv/banderas/([^"]+)"')
        if lang_audio =="": 
            lang_audio = plugintools.find_single_match(entry,'<img src="http://seriesblanco.com/banderas/([^"]+)"')
        if lang_audio.find("es.png") >= 0: lang_audio = "ESP"
        elif lang_audio.find("la.png") >= 0: lang_audio = "LAT"
        elif lang_audio.find("vos.png") >= 0: lang_audio = "V.O.S."
        elif lang_audio.find("vo.png") >= 0: lang_audio = "V.O."            
        
        url_server = plugintools.find_single_match(entry,"<img src='/servidores/([^']+)")
        url_server = url_server.replace(".png", "").replace(".jpg", "")
        quality = plugintools.find_single_match(entry,'src=\'/servidores/.*?<div class="grid_content sno">.*?<div class="grid_content sno"><span>(.*?)<')
        #if quality == "": quality = "undefined"
        server = video_analyzer(url_server)
        titlefull = params.get("title")+sc2+'[I] ['+lang_audio+'] [/I]'+ec2+sc5+'[I] ['+server+'][/I]  '+ec5+sc+'[I]'+quality+'[/I]'+ec
        ############### Tiene Redirección ###########################
        if 'enlacen' in url_capi:
            plugintools.addPeli(action="seriesblanco_liker2",title=titlefull,url=url_capi,info_labels=datamovie,thumbnail=url_img,fanart=fanart,folder=False,isPlayable=True)
        #############################################################    
        else:
            plugintools.addPeli(action=server,title=titlefull,url=url_capi,info_labels=datamovie,thumbnail=url_img,fanart=fanart,folder=False,isPlayable=True)

def seriesblanco_liker2(params):
    plugintools.log('[%s %s] Linker SeriesBlanco %s' % (addonName, addonVersion, repr(params)))

    url = params.get("url")
    
    url = 'http://seriesblanco.com'+url
    referer = url
    data = gethttp_referer_headers(url,referer)
    # onclick='window.open("http://allmyvideos.net/lh18cer7ut8r")
    url_final = plugintools.find_single_match(data, "onclick='window.open(.*?);'/>")
    url_final = url_final.replace('("', "").replace('")', "")
    #params["url"]=url_final
    #resolvers = server_analyzer(params)
    
    if url_final.find("allmyvideos") >= 0: params["url"]=url_final; allmyvideos(params)
    elif url_final.find("vidspot") >= 0: params["url"]=url_final; vidspot(params)
    elif url_final.find("played.to") >= 0: params["url"]=url_final; playedto(params)
    elif url_final.find("streamin.to") >= 0: params["url"]=url_final; streaminto(params)
    elif url_final.find("streamcloud") >= 0: params["url"]=url_final; streamcloud(params)
    elif url_final.find("nowvideo.sx") >= 0: params["url"]=url_final; nowvideo(params)
    elif url_final.find("veehd") >= 0: params["url"]=url_final; veehd(params)
    elif url_final.find("vk") >= 0: params["url"]=url_final; vk(params)
    elif url_final.find("lidplay") >= 0: params["url"]=url_final; vk(params)
    elif url_final.find("tumi.tv") >= 0: params["url"]=url_final; tumi(params)
    elif url_final.find("novamov") >= 0: params["url"]=url_final; novamov(params)
    elif url_final.find("moevideos") >= 0: params["url"]=url_final; moevideos(params)
    elif url_final.find("gamovideo") >= 0: params["url"]=url_final; gamovideo(params)
    elif url_final.find("movshare") >= 0: params["url"]=url_final; movshare(params)
    elif url_final.find("powvideo") >= 0: params["url"]=url_final; powvideo(params)
    elif url_final.find("mail.ru") >= 0: params["url"]=url_final; mailru(params)
    elif url_final.find("mediafire") >= 0: params["url"]=url_final; mediafire(params)
    elif url_final.find("netu") >= 0: params["url"]=url_final; netu(params)
    elif url_final.find("waaw") >= 0: params["url"]=url_final; waaw(params)
    elif url_final.find("movreel") >= 0: params["url"]=url_final; movreel(params)
    elif url_final.find("videobam") >= 0: params["url"]=url_final; videobam(params)    
    elif url_final.find("vimeo/videos") >= 0: params["url"]=url_final; vimeo(params)
    elif url_final.find("vimeo/channels") >= 0: params["url"]=url_final; vimeo_pl(params)
    elif url_final.find("veetle") >= 0: params["url"]=url_final; veetle(params)
    elif url_final.find("videoweed") >= 0: params["url"]=url_final; videoweed(params)
    elif url_final.find("streamable") >= 0: params["url"]=url_final; streamable(params)
    elif url_final.find("rocvideo") >= 0: params["url"]=url_final; rocvideo(params)
    elif url_final.find("realvid") >= 0: params["url"]=url_final; realvid(params)
    elif url_final.find("videomega") >= 0: params["url"]=url_final; videomega(params)
    elif url_final.find("video.tt") >= 0: params["url"]=url_final; videott(params)
    elif url_final.find("flashx") >= 0: params["url"]=url_final; flashx(params)
    elif url_final.find("openload") >= 0: params["url"]=url_final; openload(params)
    elif url_final.find("turbovideos") >= 0: params["url"]=url_final; turbovideos(params)
    elif url_final.find("ok.ru") >= 0: params["url"]=url_final; okru(params)
    elif url_final.find("vidto.me") >= 0: params["url"]=url_final; vidtome(params)
    elif url_final.find("playwire") >= 0: params["url"]=url_final; playwire(params)
    elif url_final.find("copiapop") >= 0: params["url"]=url_final; copiapop(params)
    elif url_final.find("vimple.ru") >= 0: params["url"]=url_final; vimple(params)
    elif url_final.find("vidgg") >= 0: params["url"]=url_final; vidggto(params)
    elif url_final.find("uptostream.com") >= 0: params["url"]=url_final; uptostream(params)
    elif url_final.find("youwatch") >= 0: params["url"]=url_final; youwatch(params)
    elif url_final.find("idowatch") >= 0: params["url"]=url_final; idowatch(params)
    elif url_final.find("cloudtime") >= 0: params["url"]=url_final; cloudtime(params)
    elif url_final.find("allvid") >= 0: params["url"]=url_final; allvid(params)
    elif url_final.find("vodlocker") >= 0: params["url"]=url_final; vodlocker(params)
    elif url_final.find("vidzi.tv") >= 0: params["url"]=url_final; vidzitv(params)
    elif url_final.find("streame.net") >= 0: params["url"]=url_final; streamenet(params)
    elif url_final.find("myvideoz") >= 0: params["url"]=url_final; myvideoz(params)
    elif url_final.find("streamplay") >= 0: params["url"]=url_final; streamplay(params)
    elif url_final.find("watchonline") >= 0: params["url"]=url_final; watchonline(params)
    elif url_final.find("rutube") >= 0: params["url"]=url_final; rutube(params)
    elif url_final.find("dailymotion") >= 0: params["url"]=url_final; dailymotion(params)
    elif url_final.find("auroravid") >= 0: params["url"]=url_final; auroravid(params)
    elif url_final.find("wholecloud") >= 0: params["url"]=url_final; wholecloud(params)
    elif url_final.find("bitvid") >= 0: params["url"]=url_final; bitvid(params)
    elif url_final.find("spruto") >= 0: params["url"]=url_final; spruto(params)
    elif url_final.find("stormo") >= 0: params["url"]=url_final; stormo(params)
    elif url_final.find("myvi.ru") >= 0: params["url"]=url_final; myviru(params)
    elif url_final.find("youtube.com") >= 0: params["url"]=url_final; youtube(params)
    elif url_final.find("filmon.com") >= 0: params["url"]=url_final; filmon(params)
    elif url_final.find("thevideo.me") >= 0: params["url"]=url_final; thevideome(params)
    elif url_final.find("videowood.tv") >= 0: params["url"]=url_final; videowood(params)
    elif url_final.find("neodrive.co") >= 0: params["url"]=url_final; neodrive(params)
    elif url_final.find("cloudzilla") >= 0: params["url"]=url_final; cloudzilla(params)
    elif url_final.find("thevideobee.to") >= 0: params["url"]=url_final; thevideobee(params)
    elif url_final.find("fileshow.tv") >= 0: params["url"]=url_final; fileshow(params)
    elif url_final.find("vid.ag") >= 0: params["url"]=url_final; vid(params)
    elif url_final.find("vidxtreme.to") >= 0: params["url"]=url_final; vidxtreme(params)
    elif url_final.find("vidup") >= 0: params["url"]=url_final; vidup(params)
    elif url_final.find("watchvideo") >= 0: params["url"]=url_final; watchvideo(params)
    elif url_final.find("speedvid") >= 0: params["url"]=url_final; speedvid(params)
    elif url_final.find("chefti.info") >= 0: params["url"]=url_final; exashare(params)
    elif url_final.find("ajihezo.info") >= 0: params["url"]=url_final; exashare(params)
    elif url_final.find("bojem3a.info") >= 0: params["url"]=url_final; exashare(params)
    elif url_final.find("vodbeast") >= 0: params["url"]=url_final; vodbeast(params)
    elif url_final.find("nosvideo") >= 0: params["url"]=url_final; nosvideo(params)
    elif url_final.find("noslocker") >= 0: params["url"]=url_final; noslocker(params)
    elif url_final.find("up2stream") >= 0: params["url"]=url_final; up2stream(params)
    elif url_final.find("diskokosmiko") >= 0: params["url"]=url_final; diskokosmiko(params)
    elif url_final.find("smartvid") >= 0: params["url"]=url_final; smartvid(params)
    elif url_final.find("greevid") >= 0: params["url"]=url_final; greevid(params)
    elif url_final.find("letwatch") >= 0: params["url"]=url_final; letwatch(params)
    elif url_final.find("yourupload") >= 0: params["url"]=url_final; yourupload(params)
    elif url_final.find("zalaa") >= 0: params["url"]=url_final; zalaa(params)
    elif url_final.find("uploadc") >= 0: params["url"]=url_final; uploadc(params)
    elif url_final.find("mp4upload") >= 0: params["url"]=url_final; mp4upload(params)
    elif url_final.find("rapidvideo") >= 0: params["url"]=url_final; rapidvideo(params)
    elif url_final.find("yourvideohost") >= 0: params["url"]=url_final; yourvideohost(params)
    elif url_final.find("watchers") >= 0: params["url"]=url_final; watchers(params)
    elif url_final.find("vidtodo") >= 0: params["url"]=url_final; vidtodo(params)
    elif url_final.find("izanagi") >= 0: params["url"]=url_final; izanagi(params)
    elif url_final.find("yotta") >= 0: params["url"]=url_final; yotta(params)
    elif url_final.find("kami") >= 0: params["url"]=url_final; kami(params)
    elif url_final.find("touchfile") >= 0: params["url"]=url_final; touchfile(params)
    elif url_final.find("zstream") >= 0: params["url"]=url_final; zstream(params)
    elif url_final.find("vodlock") >= 0: params["url"]=url_final; vodlock(params)
    elif url_final.find("goodvideohost") >= 0: params["url"]=url_final; goodvideohost(params)
    
def gethttp_referer_headers(url,referer):
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_3) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31"])
    request_headers.append(["Referer", referer])    
    body,response_headers = plugintools.read_body_and_headers(url, headers=request_headers)
    return body

############################################# By PalcoTv Team ####################################################
