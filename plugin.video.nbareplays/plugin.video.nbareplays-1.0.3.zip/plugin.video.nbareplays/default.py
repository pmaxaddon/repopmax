import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os
import net
net=net.Net()
ADDON = xbmcaddon.Addon(id='plugin.video.nbareplays')
maxVideoQuality = ADDON.getSetting("maxVideoQuality")
qual = ["480p", "720p", "1080p"]
maxVideoQuality = qual[int(maxVideoQuality)]
datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
cookie_path = os.path.join(datapath, 'cookies')
cookie_jar = os.path.join(cookie_path, "nba.lwp")

BASE_URL='http://tvrex.net/category/nba/'

icon = xbmc.translatePath(os.path.join('special://home/addons/nbareplays', 'icon.png'))

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

if os.path.exists(cookie_path) == False:
        os.makedirs(cookie_path)
        net.save_cookies(cookie_jar)
        
def CATEGORIES():

        link=OPEN_URL(BASE_URL).replace('\t','').replace('\r','').replace('\n','')

        match=re.compile('<div class="post-img">.+?a href="(.+?)">.+?src="(.+?)\?resize=.+?" data-hidpi=".+?" alt="(.+?)"',re.DOTALL).findall(link)

        for url,iconimage ,name in match:
            addDir(name,url,1,iconimage.replace('//','http://'),'')
            

        addDir('Next Page >>',BASE_URL,2,'','0')


                    
def MAIN(url,iconimage):

        link=OPEN_URL(url).replace('\t','').replace('\r','').replace('\n','').replace("'",'"')
        link=link.split('<p')
        for p in link:
                try:
                    name=re.compile('>(.+?)<br />').findall(p)[0]
                    url=re.compile('<iframe src="(.+?)"').findall(p)[0]
                    if 'dailymotion' in url:
                        host='DAILYMOTION'
                    elif 'playwire' in url:
                        host='PLAYWIRE' 
                    elif 'vk' in url:
                        host='VK.COM'
                    elif 'mail.ru' in url:
                        host='MAILRU'
                    elif 'openload' in url:
                        host='OPENLOAD'
                    else:
                        name=url
                        
                    name='[COLOR yellow]%s[/COLOR] - [COLOR red]%s[/COLOR]' % (name.upper(),host)

                    if not 'OPENLOAD' in name:
                        addDir(name,url,200,iconimage,'')
                except:pass
                try:
                    name=re.compile('>(.+?)<br />').findall(p)[0]
                    url=re.compile('<source src="(.+?)"').findall(p)[0]
                    if 'google' in url:
                        host='GOOGLEVIDEO'
                    else:
                        name=url
                        
                    name='[COLOR yellow]%s[/COLOR] - [COLOR red]%s[/COLOR]' % (name.upper(),host)

                
                    addDir(name,url,200,iconimage,'')
                except:pass                


                
def NEXTPAGE(pagenum):
        pagenum=int(pagenum)+1
        
        link=OPEN_URL(BASE_URL+'page/%s/' % str(pagenum))
        
        match=re.compile('<div class="post-img">.+?a href="(.+?)">.+?src="(.+?)\?resize=.+?" data-hidpi=".+?" alt="(.+?)"',re.DOTALL).findall(link)

        for url,iconimage ,name in match:
            addDir(name,url,1,iconimage.replace('//','http://'),'')
  
                
        addDir('Next Page >>',BASE_URL,2,'',str(pagenum))

 
            
def GET_GAMES(name,url,iconimage):
    link=OPEN_URL(url)

    match=re.compile('<iframe src="(.+?)"').findall(link.replace("'",'"'))
    for first in match:
        URL=first.split('//')[1]
        name=URL.split('/')[0].replace('www.','')
        url=first.replace('//www.','http://')
        addDir(name.upper(),url,200,iconimage,'')
      

            
def GrabVK(url):
    link = OPEN_URL(url.replace('amp;',''))
    name=[]
    url=[]
    r      ='"url(.+?)":"(.+?)"'
    match = re.compile(r,re.DOTALL).findall(link)
    for quality,stream in match:
        name.append(quality+'p')
        url.append(stream.replace('\/','/'))
    return url[xbmcgui.Dialog().select('Please Select Resolution', name)]

            
def getStreamUrl(id):
    maxVideoQuality = ADDON.getSetting("maxVideoQuality")
    qual = ["480p", "720p", "1080p"]
    maxVideoQuality = qual[int(maxVideoQuality)]  
    content = OPEN_URL(id)
    if '"message":"This video has been removed due to a copyright claim of WWE"' in content:
        xbmc.executebuiltin('XBMC.Notification(Info:,copyright claim (DailyMotion)!,5000)')
        return ""        
    elif content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,Not Found (DailyMotion)!,5000)')
        return ""
    else:
        matchFullHD = re.compile('"1080":.+?"url":"(.+?)"', re.DOTALL).findall(content)
        matchHD = re.compile('"720":.+?"url":"(.+?)"', re.DOTALL).findall(content)
        matchHQ = re.compile('"480":.+?"url":"(.+?)"', re.DOTALL).findall(content)
        matchSD = re.compile('"380":.+?"url":"(.+?)"', re.DOTALL).findall(content)
        matchLD = re.compile('"240":.+?"url":"(.+?)"', re.DOTALL).findall(content)
        url = ""
        if matchFullHD and maxVideoQuality == "1080p":
            url = urllib.unquote_plus(matchFullHD[0]).replace("\\", "")
        elif matchHD and (maxVideoQuality == "720p" or maxVideoQuality == "1080p"):
            url = urllib.unquote_plus(matchHD[0]).replace("\\", "")
        elif matchHQ:
            url = urllib.unquote_plus(matchHQ[0]).replace("\\", "")
        elif matchSD:
            url = urllib.unquote_plus(matchSD[0]).replace("\\", "")
        elif matchLD:
            url = urllib.unquote_plus(matchLD[0]).replace("\\", "")
        print url
        print '####################################'
        return url


def getData(url,headers={}):
    net.save_cookies(cookie_jar)
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    data=response.read()
    response.close()
    return data


def GrabMailRu(url):
    print 'RESOLVING VIDEO.MAIL.RU VIDEO API LINK'
      
    import json
    items = []
    quality = "???"
    data = getData(url)
    cookie = net.get_cookies()
    for x in cookie:

         for y in cookie[x]:

              for z in cookie[x][y]:
                   
                   l= (cookie[x][y][z])
    name=[]
    url=[]
    r = '"key":"(.+?)","url":"(.+?)"'
    match = re.compile(r,re.DOTALL).findall(data)
    for quality,stream in match:
        name.append(quality.title())
        

  
        test = str(l)
        test = test.replace('<Cookie ','')
        test = test.replace(' for .my.mail.ru/>','')
        url.append(stream +'|Cookie='+test)

    return url[xbmcgui.Dialog().select('Please Select Resolution', name)]

    
def PLAY_STREAM(name,url,iconimage):

    if 'GOOGLE' in name:
        stream_url = url

        
    if 'VK.COM' in name:
        stream_url = GrabVK(url)

                
    if 'DAILYMOTION' in name:
        stream_url = getStreamUrl(url)

    if "MAILRU" in name :
        r = 'http://videoapi.my.mail.ru/videos/embed/(.+?)\.html'
        match = re.compile(r,re.DOTALL).findall(url)[0]
        url='http://videoapi.my.mail.ru/videos/%s.json'%match
        stream_url = GrabMailRu(url)
        
        
    if 'OPENLOAD' in name:
        import urlresolver
        url=url.replace('openload.co','openload.io')
        stream_url = urlresolver.resolve(url)
        
        
    liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title':name})
    liz.setProperty("IsPlayable","true")
    liz.setPath(stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)            
            
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
    
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage,pagenum):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&pagenum="+urllib.quote_plus(pagenum)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name} )
        if mode == 200:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok        
        
        
def addLink(name,url,iconimage,description):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok 
 
                      
               
params=get_params()
url=None
name=None
mode=None
iconimage=None
pagenum=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        pagenum=urllib.unquote_plus(params["pagenum"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)
   
        
#these are the modes which tells the plugin where to go
if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        MAIN(url,iconimage)
        
elif mode==2:
        print ""+url
        NEXTPAGE(pagenum)
        
elif mode==3:
        print ""+url
        GET_GAMES(name,url,iconimage)
       
        
elif mode==200:
        print ""+url
        PLAY_STREAM(name,url,iconimage)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
