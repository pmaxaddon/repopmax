# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# Canal (18hentai) por Hernan_Ar_c
# ------------------------------------------------------------

import urlparse,urllib2,urllib,re
import os, sys


from core import logger
from core import config
from core import scrapertools
from core.item import Item
from core import servertools

__channel__ = "x18hentai"
__category__ = "S"
__type__ = "generic"
__title__ = "18hentai"
__language__ = "ES"

DEBUG = config.get_setting("debug")

host='http://www.18hentaionline.eu/'

def isGeneric():
    return True

def mainlist(item):
    logger.info("pelisalacarta.channels.18hentai mainlist")

    itemlist = []
    

    itemlist.append( Item(channel=__channel__, title="Todos", action="todas", url=host,thumbnail='', fanart=''))
    
    itemlist.append( Item(channel=__channel__, title="Sin Censura", action="todas", url=host+'tag/sin-censura/', thumbnail='', fanart=''))

    itemlist.append( Item(channel=__channel__, title="Estrenos", action="todas", url=host+'category/estreno/', thumbnail='', fanart=''))
    
    itemlist.append( Item(channel=__channel__, title="Categorias", action="categorias", url=host, thumbnail='', fanart=''))

   
    return itemlist

def todas(item):

    logger.info("pelisalacarta.channels.18hentai todas")
    itemlist = []
    data = scrapertools.cache_page(item.url)
    
    patron ='<h3><a href="([^"]+)" title="([^"]+)">.*?<\/a><\/h3>.<.*?>.<a.*?img src="([^"]+)" alt'
       
    matches = re.compile(patron,re.DOTALL).findall(data)
    for scrapedurl,scrapedtitle, scrapedthumbnail in matches: 
        url = scrapedurl
        title = scrapedtitle.decode('utf-8')
        thumbnail = scrapedthumbnail
        fanart = ''
        if (DEBUG): logger.info("title=["+title+"], url=["+url+"], thumbnail=["+thumbnail+"])")
        itemlist.append( Item(channel=__channel__, action="episodios" ,title=title , url=url, thumbnail=thumbnail, fanart=fanart ))
            
#Paginacion
    title=''
    siguiente = scrapertools.find_single_match(data,'<link rel="next" href="([^"]+)"\/>')
    title = 'Pagina Siguiente >>> '
    fanart = ''
    itemlist.append(Item(channel = __channel__, action = "todas", title =title, url = siguiente, fanart = fanart))
    return itemlist

    
def search(item,texto):
    logger.info("metaserie.py search")
    texto = texto.replace(" ","+")
    item.url = item.url+texto

    if texto!='':
        return todas(item)
    else:
        return []
        
def categorias(item):
    logger.info("pelisalacarta.channels.18hentai categoias")
    itemlist = []
    data = scrapertools.cache_page(item.url)
    patron ="<a href='([^']+)' class='tag-link-.*? tag-link-position-.*?' title='.*?' style='font-size: 11px;'>([^<]+)<\/a>" 
    
    matches = re.compile(patron,re.DOTALL).findall(data)

    for scrapedurl, scrapedtitle in matches:
	url = scrapedurl
	title = scrapedtitle
	if (DEBUG): logger.info("title=["+title+"], url=["+url+"])")
	itemlist.append( Item(channel=__channel__, action="todas" , title=title, fulltitle=item.fulltitle, url=url))
        
    return itemlist            
        


def episodios(item):
    censura = {'Si':'con censura', 'No':'sin censura'}
    logger.info("pelisalacarta.channels.18hentai episodios")
    itemlist = []
    data = scrapertools.cache_page(item.url)
    patron ='<td>([^<]+)<\/td>.<td>([^<]+)<\/td>.<td>([^<]+)<\/td>.<td>([^<]+)<\/td>.<td><a href="([^"]+)".*?>Ver Capitulo<\/a><\/td>.<\/tr>' 
    
    matches = re.compile(patron,re.DOTALL).findall(data)

    for scrapedcap, scrapedaud, scrapedsub, scrapedcen, scrapedurl in matches:
	
	url = scrapedurl
	title = 'CAPITULO '+scrapedcap+' AUDIO: '+scrapedaud+' SUB:'+scrapedsub+' '+censura[scrapedcen]
	thumbnail = ''
	plot = ''
	fanart=''
	if (DEBUG): logger.info("title=["+title+"], url=["+url+"], thumbnail=["+thumbnail+"])")
	itemlist.append( Item(channel=__channel__, action="findvideos" , title=title, fulltitle=item.fulltitle, url=url, thumbnail=item.thumbnail, plot=plot))
        
    return itemlist            
                                 
    


    
